DROP TABLE IF EXISTS project;
DROP TABLE IF EXISTS category;
DROP TABLE IF EXISTS project_category;
DROP TABLE IF EXISTS material;
DROP TABLE IF EXISTS step;

CREATE TABLE project (
	project_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	project_name VARCHAR(64) NOT NULL,
	estimated_hours INT NOT NULL,
	actual_hours INT NOT NULL,
	difficulty TEXT NOT NULL,
	notes VARCHAR(255) NOT NULL
);

CREATE TABLE category (
  category_id INT NOT NULL PRIMARY KEY,
  category_name VARCHAR(64) NOT NULL
);

CREATE TABLE project_category ( 
	project_id INT NOT NULL,
	category_id INT not NULL
);

CREATE TABLE material (
	material_id INT NOT NULL PRIMARY KEY,
	project_id INT NOT NULL,
	material_name VARCHAR(64) NOT NULL,
	num_required INT NOT NULL,
	cost DECIMAL NOT NULL,
		FOREIGN KEY (project_id) REFERENCES project(project_id)
);		
		
CREATE TABLE step (
	step_id INT not null PRIMARY KEY,
	project_id INT NOT NULL,
	step_text INT NOT NULL,
	step_order INT NOT NULL,
		FOREIGN KEY (project_id) REFERENCES project(project_id) ON DELETE CASCADE
);